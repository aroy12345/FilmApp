# FilmFlash
An Android app displaying the movies currently in theaters.

## Getting Started
### API Key
Create an `apikey.properties` file in the root directory of the project. Add the following line to
the file:
```
API_KEY = "your API key here"
```

## Authors
- [Yuying Fan](https://github.com/fyy26)
- [Ben Effress](https://github.com/Ben-Effress)
- [Aryan Roy](https://github.com/aroy12345)
